# # save as test_env.py
# from dotenv import load_dotenv
# import os

# load_dotenv()
# url = os.getenv("Neon_URL", "NOT FOUND")
# print(f"Neon_URL = {url}")

from handlers.database import DB_ENGINES

for key, val in DB_ENGINES.items():
    print(f"{key:15} → {'alias' if 'alias' in val else list(val.keys())}")